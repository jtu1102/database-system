import pymysql as pms
import datetime

connection = pms.connect(
    host = 'localhost',
    port = 3306,
    user = 'root',
    password = '1111',
    db = 'bank',
    charset = 'utf8'
)
cursor = connection.cursor()

# Manager menu functions #

# option 1: insert
#1
def insert_new_mgr(): 
    print('Insert each values')
    v = [0 for i in range(9)] # value를 담을 배열 생성 후 초기화
    v[1] = input('관리자id: ') # 프로그램 사용자에게 value 입력 받기
    v[2] = input('First name: ')
    v[3] = input('Middle name: ')
    v[4] = input('Last name: ')
    v[5] = input('소속 부서: ')
    v[6] = input('생년월일: ')
    v[7] = input('직급: ')
    v[8] = input('급여: ')

    # 입력 받은 value를 insert 하기 위한 쿼리
    insert_mgr_q = '''INSERT INTO 관리자 
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)'''
    cursor.execute(insert_mgr_q, (v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8]))
    connection.commit()

# option 2: update
#2
def update_mgr():
    set_q = input("Type list of 'attribute = value' pairs to set: ") # update 쿼리의 set 구문에 들어갈 쿼리 입력받기
    cond = input("Type the condition: ") # update 쿼리의 where 구문에 들어갈 쿼리 입력받기
    update_q = "UPDATE 관리자 " + "SET " + set_q + " WHERE " + cond + ";" # 입력 받은 내용으로 업데이트 쿼리 구성
    cursor.execute(update_q)
    connection.commit()

# option 3: delete
#3
def delete_mgr_by_id():
    id = input('id to be deleted: ') # 삭제할 관리자 id 입력받기
    # 삭제 쿼리
    delete_sql = '''DELETE FROM 관리자 
    WHERE 관리자id = %s
    '''
    cursor.execute(delete_sql, id) # 삭제 쿼리 실행
    connection.commit()

#4
def delete_mgr_by_condition():
    cond = input('Type condition for deletion: ') # 삭제 조건 입력받기
    #삭제 쿼리
    delete_sql = '''DELETE FROM 관리자
    WHERE
    '''
    delete_sql = delete_sql + cond + ';' # 입력받은 내용으로 삭제 쿼리 구성
    cursor.execute(delete_sql)
    connection.commit()

# option 4: search
#5
def show_mgr_all():
    # 관리자 리스트를 보여주는 쿼리
    show_q = '''
    SELECT * FROM 관리자;
    '''
    cursor.execute(show_q) # 쿼리 실행
    result = cursor.fetchall() # 결과 가져오기
    print('\n관리자 id, first name, middle name, last name, 소속, 생년월일, 직급, 급여')
    print('----------------------------------------------------------------------------------')
    for x in result: # 결과 출력
        for i in range(7):
            print(x[i], end=', ')
        print(x[7])
    print('----------------------------------------------------------------------------------\n')
    connection.commit()

#6
def search_mgr_by_condition():
    cnt = int(input('number of attribute to be shown: ')) # 보여줄 attribute 개수 입력받기
    att = input('Type attribute to be shown: ') # 보여줄 attribute 정보 입력받기
    cond = input('Type condition for search: ') # 검색할 조건 입력받기
    sel_q = "SELECT " + att + " FROM 관리자 " + "WHERE " + cond + ";" # 입력받은 정보로 쿼리 구성
    cursor.execute(sel_q) # 쿼리 실행
    result = cursor.fetchall()
    print(att)
    print('----------------------------------------------------------------------------------')
    for x in result: # 실행 결과 출력
        for i in range(cnt - 1):
            print(x[i], end=', ')
        print(x[cnt - 1])
    print('----------------------------------------------------------------------------------\n')
    connection.commit()


# Customer Menu functions #

# option 1: insert
#7
def insert_new_cmr():
    print('Insert each values')
    v = [0 for i in range(10)] # 사용자 value를 저장하기 위한 리스트
    v[1] = input('사용자id: ') # value 입력 받기
    v[2] = input('First name: ')
    v[3] = input('Middle name: ')
    v[4] = input('Last name: ')
    v[5] = input('대표자: ')
    v[6] = input('생년월일: ')
    v[7] = input('거래시작일: ')
    v[8] = input('신용등급: ')
    # fk로 사용되는 관리자 id 입력받기, '존재하는' 관리자의 id가 필수적으로 입력되어야 함
    # 담당직원 id는 foreign key 이므로 pk의 존재 여부를 확인해야 함 (foreign key constraint)
    available = 0 
    while available < 1:
        v[9] = input('담당직원(관리자 id로 입력): ') # 담당직원 id 입력 받기
        # 존재 여부를 확인하기 위한 쿼리
        chk_available = '''
        SELECT COUNT(*) 
        FROM 관리자
        WHERE 관리자id = %s;
        '''
        cursor.execute(chk_available, v[9])
        available = int((cursor.fetchall())[0][0])
        if available == 1: # 존재한다면 while 문 종료하고 쿼리 실행하러 가기
            break
        print("The manager id doesn't exits")

    # 사용자 insert 쿼리
    insert_cmr_q = '''INSERT INTO 사용자
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s);'''
    cursor.execute(insert_cmr_q, (v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9]))
    connection.commit()

# option 2: update
#8
def update_cmr():
    set_q = input("Type list of 'attribute = value' pairs to set: ") # set 구문의 내용 입력 받기
    cond = input("Type the condition: ") # while 구문의 내용(조건) 입력 받기
    update_q = "UPDATE 사용자 " + "SET " + set_q + "WHERE " + cond + ";" # 업데이트 쿼리 구성
    cursor.execute(update_q)
    connection.commit()

# option 3: delete
#9
def delete_cmr_by_id():
    id = input('id to be deleted: ') # 삭제할 사용자 id 입력 받기
    # 삭제 쿼리
    delete_sql = '''DELETE FROM 사용자 
    WHERE 사용자id = %s
    '''
    cursor.execute(delete_sql, id)
    connection.commit()

#10
def delete_cmr_by_condition():
    cond = input('Type condition for deletion: ') # 삭제 조건 입력 받기
    delete_sql = '''DELETE FROM 사용자
    WHERE
    '''
    delete_sql = delete_sql + cond + ';' # 삭제 쿼리 구성
    cursor.execute(delete_sql)
    connection.commit()

# option 4: search
#11
def show_cmr_all():
    show_q = '''
    SELECT * FROM 사용자;
    '''
    cursor.execute(show_q)
    result = cursor.fetchall()
    print('\n사용자 id, first name, middle name, last name, 대표자, 생년월일, 거래 시작일, 신용 등급, 담당 직원 id')
    print('------------------------------------------------------------------------------------------------------')
    for x in result:
        for i in range(8):
            print(x[i], end=', ')
        print(x[8])
    print('------------------------------------------------------------------------------------------------------\n')
    connection.commit()

#12
def search_cmr_by_condition():
    cnt = int(input('number of attribute to be shown: '))
    att = input('Type attribute to be shown: ')
    cond = input('Type condition for search: ')
    sel_q = "SELECT " + att + " FROM 사용자 " + "WHERE " + cond + ";"
    cursor.execute(sel_q)
    result = cursor.fetchall()
    print()
    print(att)
    print('------------------------------------------------------------------------------------------------------')
    for x in result:
        for i in range(cnt - 1):
            print(x[i], end=', ')
        print(x[cnt - 1])
    print('------------------------------------------------------------------------------------------------------\n')
    connection.commit()


# Service Menu functions #

# option 1: 계좌 추가 + 계좌 종류에 해당하는 서비스 추가
#13-1 (13번 함수 insert_new_account 함수에 종속되는 함수)
def insert_simple(acc):
    p = input('상품명: ') # 요구불예금 value 입력 받기
    i = input('금리(백분율): ')
    n = input('이자지급횟수: ')

    insert_sim = '''
    INSERT INTO 요구불예금
    VALUES (%s, %s, %s, %s)'''
    cursor.execute(insert_sim, (acc, p, i, n)) # 입력받은 value로 쿼리 실행
    connection.commit()

#13-2
def insert_savings(acc):
    p = input('상품명: ') # 적금 value 입력 받기
    i = input('금리(백분율): ')
    m = input('만기: ')
    s = input('계약시작일자: ')

    insert_svg = '''
    INSERT INTO 적금
    VALUES (%s, %s, %s, %s, %s)'''
    cursor.execute(insert_svg, (acc, p, i, m, s))
    connection.commit()

#13-3
def insert_loans(acc):
    p = input('상품명: ') # 대출 value 입력 받기
    c = input('담보: ')
    m = input('만기: ')
    e = input('만기연장: ')
    rm = input('상환방법: ')
    s = input('계약시작일자: ')
    i = input('이자율(백분율): ')
    b = input('대출금잔액: ')

    insert_l = '''
    INSERT INTO 대출
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)'''
    cursor.execute(insert_l, (acc, p, c, m, e, rm, s, i, b))
    connection.commit()

#13
def insert_new_account():
    # fk로 사용되는 사용자 id 입력받기, 존재하는 사용자의 id가 필수적으로 입력되어야 함
    available = 0
    while available < 1:
        cmr = input('Type the account holder id: ') # 계좌 사용자의 id 입력 받기
        chk_available = '''
        SELECT COUNT(*) 
        FROM 사용자
        WHERE 사용자id = %s;
        '''
        cursor.execute(chk_available, cmr)
        available = int((cursor.fetchall())[0][0])
        if available == 1:
            break
        print("The customer id doesn't exits")
    print('Insert new account number')
    v1 = input('계좌번호: ')
    v2 = datetime.date.today() # 계좌 개설 일자는 입력 받는 현재 날짜

    insert_acc_q = '''INSERT INTO 계좌
    VALUES (%s, %s, %s, %s)'''
    cursor.execute(insert_acc_q, (v1, 0, v2, cmr)) # 계좌 생성 시 잔액은 0, cmr은 예금를 나타내는 fk
    connection.commit()

    # 계좌 유형 설정 - 금융 상품 tuple 추가하고 연결
    print("Choose what type of service this account for") # 새로 추가하는 계좌에 연결된 금융 상품 정보 입력 받기
    print("0: 요구불예금")
    print("1: 적금")
    print("2: 대출")
    t = int(input())
    if t == 0:
        insert_simple(v1) # 요구불예금 tuple 추가하는 함수 (함수번호 13-1)
    elif t == 1:
        insert_savings(v1) # 적금 tuple 추가하는 함수 (함수번호 13-2)
    elif t == 2:
        insert_loans(v1) # 대출 tuple 추가하는 함수 (함수번호 13-3)

# option 2: 입금
#14
def new_deposit(acc):
    t = datetime.datetime.now() # 입금 시간은 현재 시간
    m = input('입금 금액: ') # 입금 금액 입력 받기
    q = '''
    INSERT INTO 계좌_입금내역
    VALUES (%s, %s, %s)
    '''
    cursor.execute(q, (acc, t, m))
    connection.commit()
    # 계좌 잔액 갱신
    # 계좌 잔액을 업데이트하는 쿼리
    # 잔액에 입금되는 금액을 더해서 업데이트함
    update_balance = '''
    UPDATE 계좌
    SET 잔액 = 잔액 + %s
    WHERE 계좌번호 = %s
    '''
    cursor.execute(update_balance, (m, acc))
    connection.commit()


# option 3: 출금
#15
def new_withdraw(acc):
    # 출금내역 기록
    t = datetime.datetime.now() # 출금 시간을 기록하기 위해 현재 시간 가져오기
    m = input('출금 금액: ') # 출금 금액 입력 받기
    q = '''
    INSERT INTO 계좌_출금내역
    VALUES (%s, %s, %s);
    '''
    cursor.execute(q, (acc, t, m)) # 쿼리 실행
    connection.commit()
    # 계좌 잔액 갱신
    # 잔액에 출금되는 금액을 빼서 업데이트함
    update_balance = '''
    UPDATE 계좌
    SET 잔액 = 잔액 - %s
    WHERE 계좌번호 = %s;
    '''
    cursor.execute(update_balance, (m, acc))
    connection.commit()
    # 출금되는 계좌가 대출 상환용 계좌라면 대출금 잔액을 갱신해야 함
    chk_l ='''
    SELECT COUNT(*)
    FROM 대출
    WHERE 상환계좌번호 = %s;
    '''
    cursor.execute(chk_l, acc)
    chk = int(cursor.fetchall()[0][0])
    if chk == 1:
        change_lb = '''
        UPDATE 대출
        SET 대출금잔액 = 대출금잔액 - %s
        WHERE 상환계좌번호 = %s;
        '''
        cursor.execute(change_lb, (m, acc))

# option 4: 계좌 정보 업데이트 - 예금주 변경
#16
def update_account():
    acc = input("Type the account number: ") # 예금주를 변경하고자 하는 계좌 번호 입력 받기
    new_holder = input("Type the new account holder id: ") # 새로운 예금주 id 입력 받기
    update_q = '''
    UPDATE 계좌
    SET 예금주id = %s
    WHERE 계좌번호 = %s;
    ''' # 업데이트 쿼리 구성
    cursor.execute(update_q, (new_holder, acc))
    connection.commit()

# option 5: 계좌 삭제
#17
def delete_account():
    acc = input('Type the account number to be deleted: ') # 삭제할 계좌 번호 입력 받기
    # 계좌 잔액이 0이 아닐 때에 대한 경고 메시지
    # 계좌 잔액이 0인지 확인하기 위해 계좌 잔액을 불러오는 쿼리
    chk_zero_q = '''
    SELECT 잔액
    FROM 계좌
    WHERE 계좌번호 = %s;
    '''
    cursor.execute(chk_zero_q, acc)
    chk = int(cursor.fetchall()[0][0])
    # 잔액이 0이 아닌 계좌의 경우, 삭제하는 것이 비상식적이므로 경고문 출력
    if chk != 0:
        print('Warning! this account have non-zero balance.') # 계좌 잔액이 0이 아닌 경우 프로그램 사용자에게 삭제 여부 한번 더 묻기
        print('0: continue')
        print('1: stop')
        op = int(input())
        if op == 1: # stop을 선택한 경우 삭제하지 않음
            return
    # fk로 연결된 tuple들 fk option에 따라 자동 삭제됨
    del_q = '''
    DELETE FROM 계좌
    WHERE 계좌번호 = %s
    '''
    cursor.execute(del_q, acc)
    connection.commit()

# option 6: 계좌 검색
#18
def show_acc_all(): # 계좌 전체 리스트 보기
    # 전체 계좌 리스트를 가져오는 쿼리
    show_q = '''
    SELECT * FROM 계좌;
    '''
    cursor.execute(show_q)
    result = cursor.fetchall()
    print('\n계좌번호, 잔액, 계좌 개설 일자, 예금주 id')
    print('------------------------------------------------')
    for x in result:
        for i in range(3):
            print(x[i], end=', ')
        print(x[3])
    print('------------------------------------------------\n')
    connection.commit()

#19
def show_acc_w_service(): # 계좌 + 상품 정보
    # 요구불예금 계좌 정보
    print('---Account for simple deposit---')
    show_q = '''
    SELECT 계좌번호, 잔액, 계좌개설일자, 예금주id, 상품명, 금리, 이자지급횟수
    FROM 계좌, 요구불예금
    WHERE 계좌번호 = 예금계좌번호
    ;
    '''
    cursor.execute(show_q)
    result = cursor.fetchall()
    print('계좌번호, 잔액, 계좌 개설 일자, 예금주 id, 상품명, 금리, 이자 지급 횟수')
    print('----------------------------------------------------------------------')
    for x in result:
        for i in range(6):
            print(x[i], end=', ')
        print(x[6])
    print('----------------------------------------------------------------------\n')
    connection.commit()

    # 적금 계좌 정보
    print('---Account for savings---')
    show_q = '''
    SELECT 계좌번호, 잔액, 계좌개설일자, 예금주id, 상품명, 금리, 만기, 계약시작일자
    FROM 계좌, 적금
    WHERE 계좌번호 = 적금계좌번호
    ;
    '''
    cursor.execute(show_q)
    result = cursor.fetchall()
    print('계좌번호, 잔액, 계좌 개설 일자, 예금주 id, 상품명, 금리, 만기, 계약 시작 일자')
    print('-----------------------------------------------------------------------------')
    for x in result:
        for i in range(7):
            print(x[i], end=', ')
        print(x[7])
    print('-----------------------------------------------------------------------------\n')
    connection.commit()
    
    # 대출 계좌 정보
    print('---Account for loans---')
    show_q = '''
    SELECT 계좌번호, 잔액, 계좌개설일자, 예금주id, 상품명, 담보, 만기, 만기연장, 상환방법, 계약시작일자, 이자율, 대출금잔액
    FROM 계좌, 대출
    WHERE 계좌번호 = 상환계좌번호
    ;
    '''
    cursor.execute(show_q)
    result = cursor.fetchall()
    print('계좌번호, 잔액, 계좌 개설 일자, 예금주 id, 상품명, 담보, 만기, 만기 연장, 상환 방법, 계약 시작 일자, 이자율, 대출금 잔액')
    print('------------------------------------------------------------------------------------------------------------------------')
    for x in result:
        for i in range(11):
            print(x[i], end=', ')
        print(x[11])
    print('------------------------------------------------------------------------------------------------------------------------\n')
    connection.commit()

#20
def show_acc_w_records(): # 계좌 + 입금, 출금 내역
    acc = input('Type account number: ')  # 입금, 출금 내역 확인 할 계좌번호 입력 받기
    print('---deposit details---') # 입금 내역 출력
    show_q = '''
    SELECT 입금시간, 입금금액
    FROM 계좌, 계좌_입금내역
    WHERE 계좌번호 = 입금계좌번호 AND 계좌번호 = %s
    ;
    '''
    cursor.execute(show_q, acc)
    result = cursor.fetchall()
    print('입금 시간, 입금 금액')
    print('--------------------------------------------')
    for x in result:
        for i in range(1):
            print(x[i], end=', ')
        print(x[1])
    print('--------------------------------------------\n')
    connection.commit()
    print('---withdraw details---')
    show_q = '''
    SELECT 출금시간, 출금금액
    FROM 계좌, 계좌_출금내역
    WHERE 계좌번호 = 출금계좌번호 AND 계좌번호 = %s
    ;
    '''
    cursor.execute(show_q, acc)
    result = cursor.fetchall()
    print('출금 시간, 출금 금액')
    print('--------------------------------------------')
    for x in result:
        for i in range(1):
            print(x[i], end=', ')
        print(x[1])
    print('--------------------------------------------')
    connection.commit()
    print('계좌 잔액: ', end='') # 마지막에 계좌 잔액 정보 출력
    # 계좌 잔액을 불러오는 쿼리
    show_q = '''
    SELECT 잔액
    FROM 계좌
    WHERE 계좌번호 = %s
    ;
    '''
    cursor.execute(show_q, acc)
    res = cursor.fetchall()[0][0]
    print(res) # 계좌 잔액 출력
    print()

#21
def search_acc_by_condition():
    cnt = int(input('number of attribute to be shown: ')) # 보여줄 attribute 개수 입력 받기
    att = input('Type attribute to be shown: ') # 보여줄 attribute 입력 받기
    cond = input('Type condition for search: ') # 검색 조건 입력 받기
    sel_q = "SELECT " + att + " FROM 계좌 " + "WHERE " + cond + ";" # 쿼리 구성
    cursor.execute(sel_q)
    result = cursor.fetchall()
    print(att)
    print('------------------------------------------------------------------------------------------------------')
    for x in result:
        for i in range(cnt - 1):
            print(x[i], end=', ')
        print(x[cnt - 1])
    print('------------------------------------------------------------------------------------------------------\n')
    connection.commit()

#22
def loan_m_extention():
    available = 0 # 입력한 계좌번호가 존재하는지 확인하는 변수, 1이면 존재
    while available < 1:
        acc = input('Type the account number: ') # 대출 만기 연장할 계좌번호 입력받기
        # 입금할 계좌번호의 존재를 확인하기 위한 쿼리
        chk_available = ''' 
        SELECT COUNT(*) 
        FROM 대출
        WHERE 상환계좌번호 = %s;
        '''
        cursor.execute(chk_available, acc) # 계좌번호 존재 여부 확인
        available = int((cursor.fetchall())[0][0]) # 계좌번호가 존재하는 경우 0이 아닌 값
        print()
        if available == 1: # 해당 계좌번호가 존재하는 경우
            break
        print("The account number doesn't exits") # 해당 계좌번호가 존재하지 않는 경우
    q = '''
    UPDATE 대출
    SET 만기연장 = 만기연장 + 1, 만기 = 만기 + 3
    WHERE 상환계좌번호 = %s;
    '''
    cursor.execute(q, acc)
    connection.commit()

#23
def update_service_by_condition():
    print('Choose service type') # 어떤 유형의 서비스 정보를 변경하고 싶은지 입력 받기
    print('0: 요구불예금')
    print('1: 적금')
    print('2: 대출')
    t = input()
    if t == '0':
        t = "요구불예금"
    elif t == '1':
        t = "적금"
    elif t == '2':
        t = "대출"
    set_q = input("Type list of 'attribute = value' pairs to set: ") # update 쿼리의 set 구문에 들어갈 쿼리 입력받기
    cond = input("Type the condition: ") # update 쿼리의 where 구문에 들어갈 쿼리 입력받기
    update_q = "UPDATE " + t + " SET " + set_q + " WHERE " + cond + ";" # 입력 받은 내용으로 업데이트 쿼리 구성
    cursor.execute(update_q)
    connection.commit()

#24
def ab_update_acc():
    set_q = input("Type list of 'attribute = value' pairs to set: ") # update 쿼리의 set 구문에 들어갈 쿼리 입력받기
    cond = input("Type the condition: ") # update 쿼리의 where 구문에 들어갈 쿼리 입력받기
    update_q = "UPDATE 계좌 " + "SET " + set_q + " WHERE " + cond + ";" # 입력 받은 내용으로 업데이트 쿼리 구성
    cursor.execute(update_q)
    connection.commit()

#25
def ab_insert_dep_rec():
    print('Insert each values')
    v = [] # value를 담을 배열 생성
    v[1] = input('입금계좌번호: ') # 프로그램 사용자에게 value 입력 받기
    v[2] = input('입금시간: ')
    v[3] = input('입금금액: ')

    # 입력 받은 value를 insert 하기 위한 쿼리
    insert_mgr_q = '''INSERT INTO 계좌_입금내역
    VALUES (%s, %s, %s)'''
    cursor.execute(insert_mgr_q, (v[1], v[2], v[3]))
    connection.commit()

#26
def ab_delete_dep_rec():
    cond = input('Type condition for deletion: ') # 삭제 조건 입력받기
    #삭제 쿼리
    delete_sql = '''DELETE FROM 계좌_입금내역
    WHERE
    '''
    delete_sql = delete_sql + cond + ';' # 입력받은 내용으로 삭제 쿼리 구성
    cursor.execute(delete_sql)
    connection.commit()

#27
def ab_update_dep_rec():
    set_q = input("Type list of 'attribute = value' pairs to set: ") # update 쿼리의 set 구문에 들어갈 쿼리 입력받기
    cond = input("Type the condition: ") # update 쿼리의 where 구문에 들어갈 쿼리 입력받기
    update_q = "UPDATE 계좌_입금내역 " + "SET " + set_q + " WHERE " + cond + ";" # 입력 받은 내용으로 업데이트 쿼리 구성
    cursor.execute(update_q)
    connection.commit()

#28
def ab_select_dep_rec():
    cnt = int(input('number of attribute to be shown: ')) # 보여줄 attribute 개수 입력받기
    att = input('Type attribute to be shown: ') # 보여줄 attribute 정보 입력받기
    cond = input('Type condition for search: ') # 검색할 조건 입력받기
    sel_q = "SELECT " + att + " FROM 계좌_입금내역 " + "WHERE " + cond + ";" # 입력받은 정보로 쿼리 구성
    cursor.execute(sel_q) # 쿼리 실행
    result = cursor.fetchall()
    print(att)
    print('----------------------------------------------------------------------------------')
    for x in result: # 실행 결과 출력
        for i in range(cnt - 1):
            print(x[i], end=', ')
        print(x[cnt - 1])
    print('----------------------------------------------------------------------------------\n')
    connection.commit()

#29
def ab_insert_wit_rec():
    print('Insert each values')
    v = [] # value를 담을 배열 생성
    v[1] = input('출금계좌번호: ') # 프로그램 사용자에게 value 입력 받기
    v[2] = input('출금시간: ')
    v[3] = input('출금금액: ')

    # 입력 받은 value를 insert 하기 위한 쿼리
    insert_mgr_q = '''INSERT INTO 계좌_출금내역
    VALUES (%s, %s, %s)'''
    cursor.execute(insert_mgr_q, (v[1], v[2], v[3]))
    connection.commit()

#30
def ab_delete_wit_rec():
    cond = input('Type condition for deletion: ') # 삭제 조건 입력받기
    #삭제 쿼리
    delete_sql = '''DELETE FROM 계좌_출금내역
    WHERE
    '''
    delete_sql = delete_sql + cond + ';' # 입력받은 내용으로 삭제 쿼리 구성
    cursor.execute(delete_sql)
    connection.commit()

#31
def ab_update_wit_rec():
    set_q = input("Type list of 'attribute = value' pairs to set: ") # update 쿼리의 set 구문에 들어갈 쿼리 입력받기
    cond = input("Type the condition: ") # update 쿼리의 where 구문에 들어갈 쿼리 입력받기
    update_q = "UPDATE 계좌_출금내역 " + "SET " + set_q + " WHERE " + cond + ";" # 입력 받은 내용으로 업데이트 쿼리 구성
    cursor.execute(update_q)
    connection.commit()

#32
def ab_select_wit_rec():
    cnt = int(input('number of attribute to be shown: ')) # 보여줄 attribute 개수 입력받기
    att = input('Type attribute to be shown: ') # 보여줄 attribute 정보 입력받기
    cond = input('Type condition for search: ') # 검색할 조건 입력받기
    sel_q = "SELECT " + att + " FROM 계좌_출금내역 " + "WHERE " + cond + ";" # 입력받은 정보로 쿼리 구성
    cursor.execute(sel_q) # 쿼리 실행
    result = cursor.fetchall()
    print(att)
    print('----------------------------------------------------------------------------------')
    for x in result: # 실행 결과 출력
        for i in range(cnt - 1):
            print(x[i], end=', ')
        print(x[cnt - 1])
    print('----------------------------------------------------------------------------------\n')
    connection.commit()

#33
def ab_insert_sim_rec():
    print('Insert each values')
    v = [] # value를 담을 배열 생성
    v[0] = input('예금계좌번호: ') # 프로그램 사용자에게 value 입력 받기
    v[1] = input('상품명: ')
    v[2] = input('금리: ')
    v[3] = input('이자지급횟수: ')

    # 입력 받은 value를 insert 하기 위한 쿼리
    insert_mgr_q = '''INSERT INTO 요구불예금
    VALUES (%s, %s, %s, %s)'''
    cursor.execute(insert_mgr_q, (v[0], v[1], v[2], v[3]))
    connection.commit()

#34
def ab_delete_sim_rec():
    cond = input('Type condition for deletion: ') # 삭제 조건 입력받기
    #삭제 쿼리
    delete_sql = '''DELETE FROM 요구불예금
    WHERE
    '''
    delete_sql = delete_sql + cond + ';' # 입력받은 내용으로 삭제 쿼리 구성
    cursor.execute(delete_sql)
    connection.commit()

#35
def ab_select_sim_rec():
    cnt = int(input('number of attribute to be shown: ')) # 보여줄 attribute 개수 입력받기
    att = input('Type attribute to be shown: ') # 보여줄 attribute 정보 입력받기
    cond = input('Type condition for search: ') # 검색할 조건 입력받기
    sel_q = "SELECT " + att + " FROM 요구불예금 " + "WHERE " + cond + ";" # 입력받은 정보로 쿼리 구성
    cursor.execute(sel_q) # 쿼리 실행
    result = cursor.fetchall()
    print(att)
    print('----------------------------------------------------------------------------------')
    for x in result: # 실행 결과 출력
        for i in range(cnt - 1):
            print(x[i], end=', ')
        print(x[cnt - 1])
    print('----------------------------------------------------------------------------------\n')
    connection.commit()

#36
def ab_insert_svg_rec():
    print('Insert each values')
    v = [] # value를 담을 배열 생성
    v[0] = input('적금계좌번호: ') # 프로그램 사용자에게 value 입력 받기
    v[1] = input('상품명: ')
    v[2] = input('금리: ')
    v[3] = input('계약 시작 일자: ')

    # 입력 받은 value를 insert 하기 위한 쿼리
    insert_mgr_q = '''INSERT INTO 적금
    VALUES (%s, %s, %s, %s)'''
    cursor.execute(insert_mgr_q, (v[0], v[1], v[2], v[3]))
    connection.commit()

#37
def ab_delete_svg_rec():
    cond = input('Type condition for deletion: ') # 삭제 조건 입력받기
    #삭제 쿼리
    delete_sql = '''DELETE FROM 적금
    WHERE
    '''
    delete_sql = delete_sql + cond + ';' # 입력받은 내용으로 삭제 쿼리 구성
    cursor.execute(delete_sql)
    connection.commit()

#38
def ab_select_svg_rec():
    cnt = int(input('number of attribute to be shown: ')) # 보여줄 attribute 개수 입력받기
    att = input('Type attribute to be shown: ') # 보여줄 attribute 정보 입력받기
    cond = input('Type condition for search: ') # 검색할 조건 입력받기
    sel_q = "SELECT " + att + " FROM 적금 " + "WHERE " + cond + ";" # 입력받은 정보로 쿼리 구성
    cursor.execute(sel_q) # 쿼리 실행
    result = cursor.fetchall()
    print(att)
    print('----------------------------------------------------------------------------------')
    for x in result: # 실행 결과 출력
        for i in range(cnt - 1):
            print(x[i], end=', ')
        print(x[cnt - 1])
    print('----------------------------------------------------------------------------------\n')
    connection.commit()

#39
def ab_insert_l_rec():
    print('Insert each values')
    v = [] # value를 담을 배열 생성
    v[0] = input('상환계좌번호: ') # 프로그램 사용자에게 value 입력 받기
    v[1] = input('상품명: ')
    v[2] = input('담보: ')
    v[3] = input('만기: ')
    v[4] = input('만기 연장: ')
    v[5] = input('상환방법')
    v[6] = input(' 계약시작일자: ')
    v[7] = input('이자율: ')
    v[8] = input('대출금잔액: ')

    # 입력 받은 value를 insert 하기 위한 쿼리
    insert_mgr_q = '''INSERT INTO 대출
    VALUES (%s, %s, %s)'''
    cursor.execute(insert_mgr_q, (v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8]))
    connection.commit()

#40
def ab_delete_l_rec():
    cond = input('Type condition for deletion: ') # 삭제 조건 입력받기
    #삭제 쿼리
    delete_sql = '''DELETE FROM 대출
    WHERE
    '''
    delete_sql = delete_sql + cond + ';' # 입력받은 내용으로 삭제 쿼리 구성
    cursor.execute(delete_sql)
    connection.commit()

#41
def ab_select_l_rec():
    cnt = int(input('number of attribute to be shown: ')) # 보여줄 attribute 개수 입력받기
    att = input('Type attribute to be shown: ') # 보여줄 attribute 정보 입력받기
    cond = input('Type condition for search: ') # 검색할 조건 입력받기
    sel_q = "SELECT " + att + " FROM 대출 " + "WHERE " + cond + ";" # 입력받은 정보로 쿼리 구성
    cursor.execute(sel_q) # 쿼리 실행
    result = cursor.fetchall()
    print(att)
    print('----------------------------------------------------------------------------------')
    for x in result: # 실행 결과 출력
        for i in range(cnt - 1):
            print(x[i], end=', ')
        print(x[cnt - 1])
    print('----------------------------------------------------------------------------------\n')
    connection.commit()


# main #
print('Hello! This is bank database management program') # 프로그램 시작 시 인사 문장
n = 1
while n > 0: # 첫번째 선택지 반복을 위한 while
    print('0: exit')
    print('1: Show Database')
    print('2: Manager Menu')
    print('3: Customer Menu')
    print('4: Service Menu')
    print('5: Abnormal case db manage')
    n = int(input())
    # Show Database #
    if n == 1: # 데이터베이스에 있는 테이블 리스트 보여주기
        q = "show tables;" # 테이블을 보여주는 쿼리
        cursor.execute(q) # 쿼리 실행
        res = cursor.fetchall() # 쿼리 결과 불러와서 저장하기
        print('--------------')
        print('Tables_in_Bank')
        print('--------------')
        for v in res: # 테이블 목록 출력
            print(v[0])
        print('--------------')
        connection.commit()
    # Manager Menu #
    elif n == 2: # ‘관리자’ table과 관련된 처리를 하는 메뉴
        while n > 0: 
            print('0: Return to previous')
            print('1: Register new manager')
            print('2: Update manager information')
            print('3: Delete manager')
            print('4: Search manager')
            n = int(input())

            # 1: register new manager
            if n == 1: # 새로운 관리자 등록
                insert_new_mgr() # 새로운 관리자 tuple을 table에 추가하는 함수 (함수번호 1)
                print('---insertion completed---\n')
            # 2: update manager information
            elif n == 2: # 관리자 정보 업데이트
                update_mgr() # 관리자 정보를 업데이트하는 함수 (함수번호 2)
                print('---update completed---')
                continue
            # 3: delete manager
            elif n == 3: # 관리자 정보 삭제
                print('0: delete by manager id')
                print('1: delete by condition')
                op = int(input())
                if op == 0: # 관리자 id로 삭제하는 경우
                    delete_mgr_by_id() # 관리자 id로 tuple삭제하는 함수 (함수번호 3)
                elif op == 1:
                    delete_mgr_by_condition() # 사용자가 입력하는 임의의 조건에 따라 tuple삭제하는 함수 (함수번호 4)
                print('---deletion completed---\n')
            # 4: search manager (select)
            elif n == 4: # 관리자 정보 보기
                print('0: Show manager list')
                print('1: Show by condition')
                op = int(input())
                if op == 0: # 전체 관리자 리스트 확인
                    show_mgr_all() # 현재 등록된 전체 관리자 리스트를 확인하는 함수 (함수번호 5)
                elif op == 1: # 조건에 의한 관리자 검색
                    search_mgr_by_condition() # 프로그램 사용자가 입력하는 임의의 조건으로 관리자를 검색하는 함수 (함수번호 6)
        n = 1
    # Customer Menu #
    elif n == 3: # ‘사용자’ table과 관련된 처리를 하는 메뉴
        while n > 0:
            print('0: Return to previous')
            print('1: Register new customer')
            print('2: Update customer information')
            print('3: Delete customer')
            print('4: Search customer')
            n = int(input())
            
            # 1: Register new customer
            if n == 1: # 새로운 사용자를 등록
                insert_new_cmr() # 새로운 사용자 tuple을 추가하는 함수 (함수번호 7)
                print('---insertion completed---')
            # 2: update customer information
            elif n == 2: # 사용자 정보를 업데이트
                update_cmr() # 사용자 정보를 업데이트하는 함수 (함수번호 8)
                print('---update completed---')
            # 3: delete customer
            elif n == 3: # 사용자 삭제
                print('0: delete by customer id')
                print('1: delete by condition')
                op = int(input())
                if op == 0: # 사용자 id로 삭제하는 경우
                    delete_cmr_by_id() # 사용자 id로 tuple을 삭제하는 함수 (함수번호 9)
                else:
                    delete_cmr_by_condition() # 프로그램 사용자가 입력하는 임의의 조건으로 tuple을 삭제하는 함수 (함수번호 10)
                print('---deletion completed---\n')
            # 4: Search customer
            elif n == 4: # 사용자 검색
                print('0: Show customer list')
                print('1: Show by condition')
                op = int(input())
                if op == 0: # 전체 사용자 리스트를 확인
                    show_cmr_all() # 전체 사용자 리스트를 보여주는 함수 (함수번호 11)
                elif op == 1: # 조건에 맞는 사용자 확인
                    search_cmr_by_condition() # 프로그램 사용자가 입력하는 임의의 조건에 맞는 사용자를 보여주는 함수 (함수번호 12)
        n = 1

        # Service Menu #
    elif n == 4: # 은행 서비스에 관련한 처리를 하는 메뉴
        while n > 0:
            print('0: Return to previous')
            print('1: Create new account')
            print('2: Deposit')
            print('3: Withdraw')
            print('4: Update account information')
            print('5: Delete account')
            print('6: Search account')
            print('7: Update service information')
            n = int(input())

            # 1: create new account
            if n == 1: # 새로운 계좌 생성
                insert_new_account() # 새로운 계좌를 생성하는 함수 (함수번호 13)
                print('---insertion completed---')
            # 2: deposit
            elif n == 2: # 입금
                # fk로 사용되는 계좌번호 입력받기, 존재하는 계좌번호가 필수적으로 입력되어야 함
                available = 0 # 입력한 계좌번호가 존재하는지 확인하는 변수, 1이면 존재
                while available < 1:
                    acc = input('Type the account number: ') # 입금할 계좌번호 입력받기
                    # 입금할 계좌번호의 존재를 확인하기 위한 쿼리
                    chk_available = ''' 
                    SELECT COUNT(*) 
                    FROM 계좌
                    WHERE 계좌번호 = %s;
                    '''
                    cursor.execute(chk_available, acc) # 계좌번호 존재 여부 확인
                    available = int((cursor.fetchall())[0][0]) # 계좌번호가 존재하는 경우 0이 아닌 값, 그 중에서도 계좌번호는 primary key 이므로 1이 available에 저장됨
                    print()
                    if available == 1: # 해당 계좌번호가 존재하는 경우
                        break
                    print("The account number doesn't exits") # 해당 계좌번호가 존재하지 않는 경우
                # 해당 계좌번호에 입금 내역 추가
                new_deposit(acc) # 해당 계좌번호에 입금 내역을 추가하는 함수 (함수 번호 14)
                print('---new deposit recorded---')
            # 3: withdraw
            elif n == 3: # 출금
                # fk로 사용되는 계좌번호 입력받기, 존재하는 계좌번호가 필수적으로 입력되어야 함
                available = 0 # 입력한 계좌번호가 존재하는지 확인하는 변수, 1이면 존재
                while available < 1:
                    acc = input('Type the account number: ') # 출금할 계좌번호 입력받기
                    chk_available = '''# 출금할 계좌번호의 존재를 확인하기 위한 쿼리
                    SELECT COUNT(*) 
                    FROM 계좌
                    WHERE 계좌번호 = %s;
                    '''
                    cursor.execute(chk_available, acc) # 계좌번호 존재 여부 확인
                    available = int((cursor.fetchall())[0][0]) # 계좌번호가 존재하는 경우 0이 아닌 값, 그 중에서도 계좌번호는 primary key 이므로 1이 available에 저장됨
                    print()
                    if available == 1: # 해당 계좌번호가 존재하는 경우 
                        break
                    print("The account number doesn't exits") # 해당 계좌번호가 존재하지 않는 경우
                # 해당 계좌번호에 출금 내역 추가
                new_withdraw(acc) # 해당 계좌번호에 출금 내역을 추가하는 함수 (함수 번호 15)
                print('---new withdraw recorded---')
            # 4: update account information
            elif n == 4: # 계좌 정보 업데이트
                update_account() # 계좌 정보를 업데이트하는 함수 (함수 번호 16)
                print('---update completed---')
            # 5: delete account
            elif n == 5: # 계좌 삭제
                delete_account() # 계좌를 삭제하는 함수 (함수 번호 17)
                print('---deletion completed---')
            # 6: search account
            elif n == 6: # 계좌 검색
                print('0: Show account list')
                print('1: Show with service information')
                print('2: Show deposit and withdraw records')
                print('3: Show by condition')
                op = int(input())
                if op == 0: # 계좌 전체 리스트 보기
                    show_acc_all() # 계좌 전체 리스트를 보여주는 함수 (함수 번호 18)
                elif op == 1: # 계좌와 상품 정보 함께 보기
                    show_acc_w_service() # 계좌와 해당 계좌가 어떤 금융 서비스를 위한 것인지 보여주는 함수 (함수 번호 19)
                elif op == 2: # 계좌와 입, 출금 내역 함께 보기
                    show_acc_w_records() # 하나의 계좌에 대한 입, 출금 내역을 보여주는 함수 (함수 번호 20)
                elif op == 3: # 프로그램 사용자가 지정한 임의의 조건에 의해 계좌를 검색
                    search_acc_by_condition() # 조건에 따라 계좌를 보여주는 함수 (함수 번호 21)
            # 7: Update service information 
            elif n == 7: 
                print('0: Loan maturity extention')
                print('1: update by condition')
                n = int(input())
                if n == 0:
                    loan_m_extention() # 대출 만기를 연장하는 함수 (함수 번호 22)
                    print('---maturity extended---')
                elif n == 1:
                    update_service_by_condition() # 사용자가 원하는 조건 대로 변경하는 함수 (함수 번호 23)
                    print('---update completed---')
        n = 1
        # Abnormal case db manage #
        # 비정상적인 상황에서 데이터베이스 관리가 필요한 경우
        # 비정상적인 상황이란, 은행의 통상적인 데이터 기록 사건에 어긋나는 상황을 의미한다. 
        # 예를 들어 입금 내역의 변경은 입금이 이루어질 때만 이루어지는 것이 통상적이지만, 비정상적 상황에서는 데이터베이스 관리자가 정보를 수정(관리)할 수 있다.
    elif n == 5:
        while n > 0:
            print('0: return to previous')
            print('1: Abnormal manage for account table')
            print('2: Abnormal manage for deposit record table')
            print('3: Abnormal manage for withdraw record table')
            print('4: Abnormal manage for simple deposits table')
            print('5: Abnormal manage for savings table')
            print('6: Abnormal manage for loans table')
            n = int(input())
            # option 1: '계좌' 테이블의 경우 예금주를 제외한 항목의 업데이트만 비정상적 상황으로 분류한다.
            if n == 1:
                ab_update_acc() # 계좌 테이블을 업데이트하는 함수 (함수 번호 24)
                # 계좌 테이블 삽입, 삭제, 조회는 정상적 상황의 메뉴로 처리
                print('---update completed---\n')
            # option 2: '계좌_입금내역' 테이블
            elif n == 2:
                print('0: Insert')
                print('1: Delete')
                print('2: Update')
                print('3: Select')
                n = int(input())
                if n == 0:
                    ab_insert_dep_rec() # 계좌_입금내역 테이블에 insert (함수 번호 25)
                elif n == 1:
                    ab_delete_dep_rec() # 계좌_입금내역 테이블에서 delete (함수 번호 26)
                elif n == 2:
                    ab_update_dep_rec() # 계좌_입금내역 테이블 update (함수 번호 27)
                elif n == 3:
                    ab_select_dep_rec() # 계좌_입금내역 테이블 select (함수 번호 28)
            # option 3: '계좌_출금내역' 테이블
            elif n == 3:
                print('0: Insert')
                print('1: Delete')
                print('2: Update')
                print('3: Select')
                n = int(input())
                if n == 0:
                    ab_insert_wit_rec() # 계좌_출금내역 테이블에 insert (함수 번호 29)
                elif n == 1:
                    ab_delete_wit_rec() # 계좌_출금내역 테이블에서 delete (함수 번호 30)
                elif n == 2:
                    ab_update_wit_rec() # 계좌_출금내역 테이블 update (함수 번호 31)
                elif n == 3:
                    ab_select_wit_rec() # 계좌_출금내역 테이블 select (함수 번호 32)
            # option 4: '요구불예금' 테이블
            elif n == 4:
                print('0: Insert')
                print('1: Delete')
                print('2: Select')
                n = int(input())
                if n == 0:
                    ab_insert_sim_rec() # 요구불예금 테이블에 insert (함수 번호 33)
                elif n == 1:
                    ab_delete_sim_rec() # 요구불예금 테이블에서 delete (함수 번호 34)
                elif n == 2:
                    ab_select_sim_rec() # 요구불예금 테이블 select (함수 번호 35)
            # option 5: '적금' 테이블
            elif n == 5:
                print('0: Insert')
                print('1: Delete')
                print('2: Select')
                n = int(input())
                if n == 0:
                    ab_insert_svg_rec() # 적금 테이블에 insert (함수 번호 36)
                elif n == 1:
                    ab_delete_svg_rec() # 적금 테이블에서 delete (함수 번호 37)
                elif n == 2:
                    ab_select_svg_rec() # 적금 테이블 select (함수 번호 38)
            # option 6: '대출' 테이블
            elif n == 6:
                print('0: Insert')
                print('1: Delete')
                print('2: Select')
                n = int(input())
                if n == 0:
                    ab_insert_l_rec() # 대출 테이블에 insert (함수 번호 39)
                elif n == 1:
                    ab_delete_l_rec() # 대출 테이블에서 delete (함수 번호 40)
                elif n == 2:
                    ab_select_l_rec() # 대출 테이블 select (함수 번호 41)
        n = 1

connection.close()
