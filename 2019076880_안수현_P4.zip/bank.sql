-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        8.0.27 - MySQL Community Server - GPL
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- bank 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `bank` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bank`;

-- 테이블 bank.계좌 구조 내보내기
CREATE TABLE IF NOT EXISTS `계좌` (
  `계좌번호` char(14) NOT NULL,
  `잔액` double NOT NULL,
  `계좌개설일자` date DEFAULT NULL,
  `예금주id` int NOT NULL,
  PRIMARY KEY (`계좌번호`),
  KEY `예금주id` (`예금주id`),
  CONSTRAINT `계좌_ibfk_1` FOREIGN KEY (`예금주id`) REFERENCES `사용자` (`사용자id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.계좌:~5 rows (대략적) 내보내기
/*!40000 ALTER TABLE `계좌` DISABLE KEYS */;
INSERT INTO `계좌` (`계좌번호`, `잔액`, `계좌개설일자`, `예금주id`) VALUES
	('10101010101010', 0, '2021-12-03', 1),
	('11111111111111', 751400, '2021-12-01', 1),
	('12345678912345', 1990, '2021-12-03', 1),
	('22222222222222', 200000, '2021-11-30', 3),
	('83630204280940', 0, '2018-10-03', 2);
/*!40000 ALTER TABLE `계좌` ENABLE KEYS */;

-- 테이블 bank.계좌_입금내역 구조 내보내기
CREATE TABLE IF NOT EXISTS `계좌_입금내역` (
  `입금계좌번호` char(14) NOT NULL,
  `입금시간` datetime NOT NULL,
  `입금금액` double NOT NULL,
  PRIMARY KEY (`입금계좌번호`,`입금시간`,`입금금액`),
  CONSTRAINT `계좌_입금내역_ibfk_1` FOREIGN KEY (`입금계좌번호`) REFERENCES `계좌` (`계좌번호`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.계좌_입금내역:~7 rows (대략적) 내보내기
/*!40000 ALTER TABLE `계좌_입금내역` DISABLE KEYS */;
INSERT INTO `계좌_입금내역` (`입금계좌번호`, `입금시간`, `입금금액`) VALUES
	('10101010101010', '2021-12-03 12:10:45', 40),
	('12345678912345', '2021-11-29 19:45:32', 1),
	('12345678912345', '2021-11-29 19:45:58', 1000),
	('12345678912345', '2021-11-29 19:46:18', 4),
	('12345678912345', '2021-11-30 18:00:59', 1000),
	('22222222222222', '2021-12-01 14:39:50', 12),
	('83630204280940', '2021-12-01 14:31:11', 1000000);
/*!40000 ALTER TABLE `계좌_입금내역` ENABLE KEYS */;

-- 테이블 bank.계좌_출금내역 구조 내보내기
CREATE TABLE IF NOT EXISTS `계좌_출금내역` (
  `출금계좌번호` char(14) NOT NULL,
  `출금시간` datetime NOT NULL,
  `출금금액` double NOT NULL,
  PRIMARY KEY (`출금계좌번호`,`출금시간`,`출금금액`),
  CONSTRAINT `계좌_출금내역_ibfk_1` FOREIGN KEY (`출금계좌번호`) REFERENCES `계좌` (`계좌번호`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.계좌_출금내역:~9 rows (대략적) 내보내기
/*!40000 ALTER TABLE `계좌_출금내역` DISABLE KEYS */;
INSERT INTO `계좌_출금내역` (`출금계좌번호`, `출금시간`, `출금금액`) VALUES
	('10101010101010', '2021-12-01 22:57:28', 10),
	('10101010101010', '2021-12-01 22:59:06', 10),
	('10101010101010', '2021-12-01 23:00:28', 10),
	('10101010101010', '2021-12-01 23:02:24', 10),
	('12345678912345', '2021-11-29 19:47:19', 5),
	('12345678912345', '2021-11-29 19:47:32', 0),
	('12345678912345', '2021-11-29 22:00:15', 10),
	('22222222222222', '2021-12-01 14:40:15', 12),
	('83630204280940', '2021-12-01 14:31:32', 248600);
/*!40000 ALTER TABLE `계좌_출금내역` ENABLE KEYS */;

-- 테이블 bank.관리자 구조 내보내기
CREATE TABLE IF NOT EXISTS `관리자` (
  `관리자id` int NOT NULL,
  `Mfname` varchar(20) NOT NULL,
  `Mmname` varchar(20) DEFAULT NULL,
  `Mlname` varchar(20) NOT NULL,
  `소속` varchar(20) NOT NULL,
  `생년월일` date DEFAULT NULL,
  `직급` varchar(20) DEFAULT NULL,
  `급여` double DEFAULT NULL,
  PRIMARY KEY (`관리자id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.관리자:~4 rows (대략적) 내보내기
/*!40000 ALTER TABLE `관리자` DISABLE KEYS */;
INSERT INTO `관리자` (`관리자id`, `Mfname`, `Mmname`, `Mlname`, `소속`, `생년월일`, `직급`, `급여`) VALUES
	(1, 'soohyun', NULL, 'Lee', 'it', '1999-11-02', 'boss', 100000000),
	(2, 'jeonghyun', NULL, 'Lee', 'it', '2003-03-03', 'emp', 1000000),
	(3, 'yoohyun', NULL, 'Park', 'it', '1999-02-03', 'emp', 1200000),
	(4, 'surl', NULL, 'ahn', 'it', '2011-12-18', 'boss', 5000000);
/*!40000 ALTER TABLE `관리자` ENABLE KEYS */;

-- 테이블 bank.대출 구조 내보내기
CREATE TABLE IF NOT EXISTS `대출` (
  `상환계좌번호` char(14) NOT NULL,
  `상품명` varchar(100) NOT NULL,
  `담보` varchar(50) DEFAULT NULL,
  `만기` int NOT NULL DEFAULT '1',
  `만기연장` int NOT NULL DEFAULT '0',
  `상환방법` varchar(20) DEFAULT NULL,
  `계약시작일자` date NOT NULL,
  `이자율` float NOT NULL,
  `대출금잔액` double NOT NULL,
  PRIMARY KEY (`상환계좌번호`,`상품명`),
  CONSTRAINT `대출_ibfk_1` FOREIGN KEY (`상환계좌번호`) REFERENCES `계좌` (`계좌번호`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.대출:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `대출` DISABLE KEYS */;
INSERT INTO `대출` (`상환계좌번호`, `상품명`, `담보`, `만기`, `만기연장`, `상환방법`, `계약시작일자`, `이자율`, `대출금잔액`) VALUES
	('10101010101010', '주택담보대출', 'house', 11, 3, '만기일시상환', '2019-01-01', 1, 0),
	('12345678912345', '학자금대출', NULL, 3, 0, '원리금균등상환', '2021-11-29', 1.1, 1000000);
/*!40000 ALTER TABLE `대출` ENABLE KEYS */;

-- 테이블 bank.사용자 구조 내보내기
CREATE TABLE IF NOT EXISTS `사용자` (
  `사용자id` int NOT NULL,
  `Cfname` varchar(20) NOT NULL,
  `Cmname` varchar(20) DEFAULT NULL,
  `Clname` varchar(20) DEFAULT NULL,
  `대표자` varchar(20) DEFAULT NULL,
  `생년월일` date DEFAULT NULL,
  `거래시작일` date DEFAULT NULL,
  `신용등급` varchar(2) DEFAULT NULL,
  `담당직원` int DEFAULT NULL,
  PRIMARY KEY (`사용자id`),
  KEY `담당직원` (`담당직원`),
  CONSTRAINT `사용자_ibfk_1` FOREIGN KEY (`담당직원`) REFERENCES `관리자` (`관리자id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.사용자:~4 rows (대략적) 내보내기
/*!40000 ALTER TABLE `사용자` DISABLE KEYS */;
INSERT INTO `사용자` (`사용자id`, `Cfname`, `Cmname`, `Clname`, `대표자`, `생년월일`, `거래시작일`, `신용등급`, `담당직원`) VALUES
	(1, 'Thomas', 'William', 'Hiddleston', '', '1999-09-02', '2021-01-01', 'A', 1),
	(2, 'Jaehyun', NULL, 'Jung', '', '1997-02-14', '2021-12-01', 'A+', 1),
	(3, 'Mark', NULL, 'Lee', '', '1999-03-01', '2021-12-01', 'B', 2),
	(4, 'Samsung', NULL, NULL, 'Jaeyong Lee', '1979-09-01', '2021-08-30', 'B+', 3);
/*!40000 ALTER TABLE `사용자` ENABLE KEYS */;

-- 테이블 bank.요구불예금 구조 내보내기
CREATE TABLE IF NOT EXISTS `요구불예금` (
  `예금계좌번호` char(14) NOT NULL,
  `상품명` varchar(100) NOT NULL,
  `금리` float NOT NULL,
  `이자지급횟수` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`예금계좌번호`,`상품명`),
  CONSTRAINT `요구불예금_ibfk_1` FOREIGN KEY (`예금계좌번호`) REFERENCES `계좌` (`계좌번호`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.요구불예금:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `요구불예금` DISABLE KEYS */;
INSERT INTO `요구불예금` (`예금계좌번호`, `상품명`, `금리`, `이자지급횟수`) VALUES
	('11111111111111', '단순예금', 1.5, 3),
	('83630204280940', '단순예금', 1.5, 5);
/*!40000 ALTER TABLE `요구불예금` ENABLE KEYS */;

-- 테이블 bank.적금 구조 내보내기
CREATE TABLE IF NOT EXISTS `적금` (
  `적금계좌번호` char(14) NOT NULL,
  `상품명` varchar(100) NOT NULL,
  `금리` float NOT NULL,
  `만기` int NOT NULL DEFAULT '1',
  `계약시작일자` date NOT NULL,
  PRIMARY KEY (`적금계좌번호`,`상품명`),
  CONSTRAINT `적금_ibfk_1` FOREIGN KEY (`적금계좌번호`) REFERENCES `계좌` (`계좌번호`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.적금:~1 rows (대략적) 내보내기
/*!40000 ALTER TABLE `적금` DISABLE KEYS */;
INSERT INTO `적금` (`적금계좌번호`, `상품명`, `금리`, `만기`, `계약시작일자`) VALUES
	('22222222222222', '정기적금', 2, 6, '2021-12-01');
/*!40000 ALTER TABLE `적금` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
